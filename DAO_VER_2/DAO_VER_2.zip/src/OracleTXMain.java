import java.util.ArrayList;

import com.dto.Dept;
import com.service.OracleTXService;

public class OracleTXMain {

	public static void main(String[] args) {
		
		OracleTXService service = new OracleTXService();
		
		try {
			ArrayList<Dept> list = service.select();
			for(Dept d : list) {
				System.out.println(d);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
