package com.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

import com.dao.OracleTXDAO;
import com.dto.Dept;

public class OracleTXService {
	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String userid = "scott";
	String passwd = "tiger";
	OracleTXDAO dao;
	
	public OracleTXService() {
		super();
		dao = new OracleTXDAO();
		try {
			Class.forName(driver);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Dept> select() throws SQLException {
		Connection con = null;
		ArrayList<Dept> list= null;	
		try {
			con = DriverManager.getConnection(url, userid, passwd);
			list = dao.select(con);
			
		} finally{
			if(con != null) con.close();
		}
		return list;
	}
	
	
}
