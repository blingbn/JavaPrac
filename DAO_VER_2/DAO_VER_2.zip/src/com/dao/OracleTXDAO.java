package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.dto.Dept;

public class OracleTXDAO {
	
	
	public ArrayList<Dept> select(Connection con) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<Dept> list = new ArrayList<Dept>();
	
		String sql = "select * from dept";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			int deptno = rs.getInt(1);
			String dname = rs.getString(2);
			String loc = rs.getString(3);	
			Dept dept = new Dept(deptno, dname, loc);
			list.add(dept);
				
		}
					
		if(rs != null)rs.close();
		if(pstmt != null)pstmt.close();
			
			
		
		return list;
		
	}
}
