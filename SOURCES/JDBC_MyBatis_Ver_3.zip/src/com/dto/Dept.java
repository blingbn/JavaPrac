package com.dto;

public class Dept {
	 int deptno;
	String dname;
	String loc;



	@Override
	public String toString() {
		return "Dept [deptno=" + deptno + ", dname=" + dname + ", loc=" + loc + "]";
	}
	public Dept() {
		super();
		System.out.println("기본생성자 호출 ===================");
	}
	public Dept(int deptno, String dname, String loc) {
		super();
		this.deptno = deptno;
		this.dname = dname;
		this.loc = loc;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLoc() {
		
		return loc;
	}
	public void setLoc(String loc) {
		System.out.println("setLoc 호출");
		this.loc = loc;
	}
	

}
