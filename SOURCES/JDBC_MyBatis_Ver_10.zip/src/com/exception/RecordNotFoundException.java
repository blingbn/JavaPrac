package com.exception;

public class RecordNotFoundException extends Exception{

	public RecordNotFoundException(String message) {
		super(message);//사용자 정의 메세지
		// TODO Auto-generated constructor stub
	}

}
