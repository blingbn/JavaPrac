import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.dto.Dept;
import com.exception.RecordNotFoundException;
import com.service.OracleMyBatisService;

public class OralceMyBatisMain4 {

	public static void main(String[] args) {
		OracleMyBatisService service= new OracleMyBatisService();
		
		int deptno=10;
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("deptno", null);
//		map.put("deptno", 10); //key값을  이용한 검사
		List<Dept> list= service.selectDynamicDeptno(map);//동적 sql사용 
		//deptno를 검사 해서 deptno != null 이 경우에 동적으로  sql where 조건 절 추가 
		
		
		
		for (Dept dept : list) {
			System.out.println(dept);
		}
	}

}
