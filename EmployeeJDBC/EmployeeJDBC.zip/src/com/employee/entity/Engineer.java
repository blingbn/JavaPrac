package com.employee.entity;

public class Engineer extends Employee {

	public Engineer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Engineer(int empno, String ename, String hiredate, String loc, int sal, String state) {
		super(empno, ename, hiredate, loc, sal, state);
		// TODO Auto-generated constructor stub
	}

	

	
}
